<script>
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();
});
</script>
